package com.gb.relation;

public enum Relation {
    Wife, Child, Father, Brother, Sister, Husnband, Husband, Mother
}
