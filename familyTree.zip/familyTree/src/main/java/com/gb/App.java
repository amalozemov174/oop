package com.gb;

import com.gb.command.Command;
import com.gb.command.CommandA;
import com.gb.command.CommandL;
import com.gb.command.CommandExit;
import com.gb.command.CommandToTree;
import com.gb.command.FamilyTreeCommand;
import com.gb.comparator.HumanComparatorByDate;
import com.gb.relation.Human;
import com.gb.relation.Relatives;
import com.gb.tree.FamilyTree;
import com.gb.view.View;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;

public class App {


        public static void main(String[] args) throws IOException, ClassNotFoundException {
            FamilyTree familyTree = new FamilyTree();
            FamilyTreeCommand familyTreeCommand = new FamilyTreeCommand(familyTree);
            View view = new View();
            ArrayList<Command> commands = new ArrayList<>();
            CommandA a = new CommandA();
            CommandL l = new CommandL();
            CommandExit exit = new CommandExit();
            commands.add(a);
            commands.add(l);
            commands.add(exit);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
            String command = "";
            view.getStartWork();
            while (!command.equals(exit.getName())) {
                view.getAllComand(commands);
                command = bufferedReader.readLine();
                if(command.equals(a.getName())){
                    view.addHumanToTree(bufferedReader, familyTreeCommand);
//                    System.out.println("введите параметры человека в формате:");
//                    System.out.println("пол male/female");
//                    boolean male = bufferedReader.readLine().equals("male");
//                    System.out.println("имя");
//                    String name = bufferedReader.readLine();
//                    System.out.println("Фамилия");
//                    String surname = bufferedReader.readLine();
//                    System.out.println("Дата рождения(год-месяц-день)");
//                    String date = bufferedReader.readLine();
//                    String format[] = date.split("-");
//                    Date d = new Date(Integer.parseInt(format[0]), Integer.parseInt(format[1]),Integer.parseInt(format[2]));
//                    System.out.println("Извесны ли родители?(да/нет)");
//                    String parents = bufferedReader.readLine();
//                    if(parents.equals("да")){
//                        System.out.println("Введите имя и фамилию 1го родителя(имя фамилия)");
//                        String parent1 = bufferedReader.readLine();
//                        String[] par1 = parent1.split(" ");
//                        Human h1 = familyTreeCommand.getFamilyMemberByNameAndSurname(par1[0], par1[1]);
//                        System.out.println("Введите имя и фамилию 2го родителя(имя фамилия)");
//                        String parent2 = bufferedReader.readLine();
//                        String[] par2 = parent1.split(" ");
//                        Human h2 = familyTreeCommand.getFamilyMemberByNameAndSurname(par2[0], par2[1]);
//                        Human h = new Human(h1, h2, male, name, surname, d);
//                        System.out.println("Добавлен член семьи");
//                        System.out.println(h);
//                        familyTreeCommand.addFamilyMember(h);
//                    }
//                    else {
//                        Human h = new Human(male, name, surname, d);
//                        System.out.println("Добавлен член семьи");
//                        System.out.println(h);
//                        familyTreeCommand.addFamilyMember(h);
//                    }
                }
                else if(command.equals(l.getName())){
                    view.getAllFamilyTreeMembers(familyTreeCommand);
//                    System.out.println("Все члены семьи");
//                    System.out.println(familyTreeCommand.getFamilyMembers());
                }
                else {
                    view.notRecognizedCommand();
                }

            }
        }

    }
