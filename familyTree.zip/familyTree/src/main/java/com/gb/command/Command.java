package com.gb.command;

public abstract class Command {

    public abstract String getDescription();

    public abstract String getName();

}
