package com.gb.command;

public class CommandL extends Command {
    private final String description = "показать семейное древо";
    private final String name = "l";

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }
}
